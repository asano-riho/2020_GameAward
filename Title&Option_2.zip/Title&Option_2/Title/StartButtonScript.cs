﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartButtonScript : MonoBehaviour
{
    //StartButton押下時の処理
    public void OnClickStartButton()
    {
        SceneManager.LoadScene("SampleScene");    //ゲームシーンへ移行
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
