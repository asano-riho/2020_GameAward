﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TitleBackScript : MonoBehaviour
{
    //TitleBackButton押下時の処理
    public void OnClickTitleBackButton()
    {
        SceneManager.LoadScene("Title");    //タイトル画面へ移行
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
